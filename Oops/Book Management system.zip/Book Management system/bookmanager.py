
class BooKManger:
     def isBookAbvaible(self, bookId):
        print ("Book is avaialble")

     def issueBook(self, bookId, student):
         print("book issued to student")
    
     def acceptBook(self, bookId, student):
         print("Book is returned by studnet")
     def removeFromLibrary(sefl, bookId):
         print("Books removed from libary")
          
