class books :
    def __init__(self,BookId,  Bookname , author, edition, price, quantity ):
        self.BookId = BookId
        self.Bookname =  Bookname 
        self.author = author
        self.edition = edition
        self.price = price
        self.quantity = quantity
    
    