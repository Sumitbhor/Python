class BookManager :
    